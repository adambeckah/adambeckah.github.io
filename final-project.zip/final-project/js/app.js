var scrollTop = 0;
var $firstImages = $('.first-images');
var pullQuote1Left = 0;
var quotesPulledToPosition = {
	firstQuote: false,
	pullQuote1: $('.pull-quote-1'),
	secondQuote: false,
	pullQuote2: $('.pull-quote-2')
};



$(window).scroll(function () {
	// possibly base actions on scrollTop + window.height

	scrollTop = $(window).scrollTop();
	
	// console.log(scrollTop);

	topImageFade();

	quotePull(2650, 4000, 'pullQuote1', 'firstQuote' , 'left');

	quotePull(3000, 5000, 'pullQuote2', 'secondQuote' , 'right');

});



function topImageFade() {
	if (scrollTop > 100) {
		$firstImages.css('opacity' , 1 - (scrollTop - 100) / 500);
	}
}

// function firstQuotePullLeft () {
// 	if (scrollTop > 2750 && scrollTop < 4000) {

// 		pullQuote1Left = 100 - (scrollTop - 2750);

// 		console.log(pullQuote1Left);

// 		if (pullQuote1Left >= 0 && !hasPullQuote1LeftBeenPulledLeft) {
// 			$pullQuote1.css('left' , pullQuote1Left + '%');
// 		} else {
// 			hasPullQuote1LeftBeenPulledLeft = true;
// 			$pullQuote1.css('left' , 0);
// 		}
// 	}
// }


function quotePull (minScrollTop, maxScrollTop, $pullQuote, quoteNum, direction ) {
	console.log(scrollTop);
	if (scrollTop > minScrollTop && scrollTop < maxScrollTop) {

		pullQuoteOffset = 100 - ((scrollTop - minScrollTop) * .5);

		if (pullQuoteOffset >= 0 && !quotesPulledToPosition[quoteNum]) {
			quotesPulledToPosition[$pullQuote].css(direction , pullQuoteOffset + '%');
		} else {
			quotesPulledToPosition[quoteNum] = true;

			quotesPulledToPosition[$pullQuote].css(direction , 0);
		}
	}
}




